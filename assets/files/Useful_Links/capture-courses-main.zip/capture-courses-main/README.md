# capture-courses

## 使用说明
打开浏览器开发者工具, 使用[Edge](https://learn.microsoft.com/en-us/microsoft-edge/devtools-guide-chromium/javascript/overrides)或[Chrome](https://developer.chrome.com/docs/devtools/overrides?hl=zh-cn)的本地覆写, 将 folder for overrides 设为本仓库目录下的 overrides, 然后即可正常访问USTC在线视频平台的[直录播-录播课程](https://v.ustc.edu.cn/capture-course/), 也可以查询到课程号后直接访问 https://v.ustc.edu.cn/0/2023-2/capture-course/课程号/detail

## 往期课程支持
在[直录播-录播课程](https://v.ustc.edu.cn/capture-course/)的搜索框输入"**搜索内容?past=学期数**", 其中学期数为0至7的整数(0表示当前学期, 包含夏季学期), 如"相对论?past=3"